# GroupRecommendations

- run:

```sh
cd src/
python3 main.py --input ../data/ml_small/ --model mpe --mpth 0.4
```

